<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "m", "police");
$id = $_GET['id'];
$result = $conn->query("SELECT id, name, created_at FROM divisions where id = '$id'");

$outp = "";
while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
    $outp .= '{"id":"'  . $rs["id"] . '",';
    $outp .= '"name":"'   . $rs["name"]        . '",';
    $outp .= '"created_at":"'. $rs["created_at"]     . '"}';
}
$outp ='['.$outp.']';
$conn->close();

echo($outp);
?>